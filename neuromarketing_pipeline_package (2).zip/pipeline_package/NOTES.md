# Computational Neuromarketing Pipeline — Project Notes
**For: Aditya Dixit — portfolio/interview reference**
**What this document is:** the full chain-of-thought, methodology, results, and honest limitations of the pre-launch ad-attention screening pipeline built across this conversation. Written so you can study it, quote from it, and explain it in an interview without needing to read Python.

---

## 1. One-line description (for a CV bullet or opening answer)

> Built a computational attention-screening pipeline in Python (OpenCV, ONNX face detection, OCR-based AOI mapping) to flag competing focal points and predict attention distribution on WhatsApp ad creative before it goes to spend — modeled conceptually on how commercial neuromarketing platforms structure their reporting, and validated its own limitations by comparing outputs against a real industry technical paper (Neurons AI).

## 2. Why this project exists

You were manually reviewing AI-generated WhatsApp banner creative for Paisabazaar's PLPA product and kept running into the same problem: multiple AI tools (Grok, ChatGPT, Kimi) would score creative with impressive-looking numbers ("Neuromarketing Score: 9.3/10", "Brand Recall Strength: 82%") with no real basis — no eye-tracking data, no validation, just an LLM inventing plausible-sounding output. You wanted something that either (a) computed real, checkable numbers from a real algorithm, or (b) was honest that it couldn't. That's the whole premise of this project.

## 3. Chain of thought — the actual debugging journey

This is the part worth telling in an interview, because it shows real problem-solving under real constraints, not a tutorial you followed.

1. **Started with the question**: can any of this be computed for real, not invented? Answer: yes, partially — bottom-up visual saliency is a real, decades-old, published field of computer vision. Not the same as real eye-tracking, but a real, citable heuristic.
2. **Installed `opencv-contrib-python-headless`** to get OpenCV's `saliency` module, and ran **Spectral Residual saliency** (Hou & Zhang, 2007) — a real published algorithm that estimates visual attention from an image's frequency spectrum.
3. **Added a face-detection attention prior**, because faces are one of the most well-replicated findings in real eye-tracking literature (people look at faces first, reliably). First attempt: OpenCV's built-in **Haar cascade** face detector.
4. **Haar cascade failed** — it false-positived on cash and phone-screen texture, detecting "3 faces" on a banner that had exactly one real face. Caught this by drawing the detected boxes on the image and looking (a debug visualization), not just trusting the numbers.
5. **Tried to fix it with a DNN-based detector** (Caffe SSD, a common face-detection model) — hit a real, current infrastructure wall: modern OpenCV builds have **removed the Caffe model importer entirely**. Confirmed via the actual error message, not assumed.
6. **Switched to UltraFace RFB-320**, a lightweight face detector distributed in **ONNX format** (a cross-framework model file format that OpenCV can load directly) — this worked, confirmed by re-running the debug visualization and seeing exactly one correct face box per image.
7. **Combined the saliency map + face-prior into a single heatmap**, weighted 45% saliency / 55% face-prior, rendered as a heatmap overlay.
8. **First version of "gaze path"**: picked the top-5 brightest points on the heatmap directly (pixel-level local maxima) and connected them with numbered arrows to simulate a scanpath. This was crude — it didn't know what those bright points *were* commercially.
9. **Upgraded to AOI (Area-of-Interest)-based scoring** after reading a real industry technical paper (Neurons AI's whitepaper — see Section 6) which showed that real commercial tools don't just report a heatmap blob, they report **% of attention landing inside named, commercially relevant regions** (logo, headline, offer amount, CTA, etc.).
10. **Added real OCR** (Tesseract) to detect text regions automatically rather than eyeballing coordinates, then grouped OCR words into logical AOI boxes (headline, offer amount, cashback line, CTA) by hand.
11. **Built a Focus/concentration score** — this is the direct technical answer to the exact problem you described in your own words: *"too many focus points means the brain has to allocate more [resources]."* Implemented as **normalized entropy** across the AOI attention-share distribution (see Section 5 for the formula and why entropy is the right tool for this).
12. **Built a competition detector** — flags any two AOIs whose attention shares are close *and* whose boxes are spatially near each other, which is the computational definition of "these two things are fighting for the same glance."
13. **Ran the full pipeline on the original creative**, found real competition (Face vs. Bank Logo; Offer Amount vs. Cashback line) and a bigger structural problem (69% of attention going to background gradient glow, not to any commercial element at all).
14. **Attempted fixes via pixel post-processing** (desaturating competing elements, boosting the offer amount's contrast, adding a missing CTA button) — this **worked** on the original, simple flat-graphic creative (Focus score improved, two of three competitions resolved).
15. **Tried the same post-processing approach on a richer AI-generated photorealistic banner** — it **barely worked** (Focus score moved from 0.338 to 0.347, essentially flat). Investigated why with a **controlled isolated experiment**: built two identical mock buttons, one flat-filled, one bordered, and proved the algorithm scores the bordered one ~45% higher purely from edge complexity, regardless of actual color contrast — a real, demonstrated bias in this class of algorithm.
16. **Tried a real layout change instead of color tweaks** on the same image (relocating and shrinking two competing graphic elements, not just dimming them) — this worked substantially better (Focus score 0.338 → 0.476), proving the diagnosis: *cosmetic post-processing can't fix structural competition; only layout changes can.*
17. **Concluded the real fix had to happen at the image-generation stage**, not in post-processing — wrote a detailed, AOI-informed prompt (plain low-texture background, generous negative space around the face, explicit visual hierarchy instructions) and had it generated fresh in ChatGPT (gpt-image-1).
18. **Re-ran the identical pipeline on the new generation** — Focus score jumped to 0.505 (best result across every version tried), and the offer amount went from a three-way tie at ~13% to a dominant 40.7% share, completely resolving the original face-vs-text competition.
19. **Added AOI-level gaze-path visualization** (this was a gap you caught yourself) — instead of just reporting *how much* attention each AOI gets, the pipeline now also reports and draws the *predicted order* AOIs get fixated in, so you can visually and numerically check whether the sequence tells a coherent story (logo → offer → face → CTA) or jumps around incoherently.

## 4. What each core algorithm actually is (glossary, since you don't read Python)

| Term | Plain-English meaning |
|---|---|
| **Saliency** | A computed estimate of which pixels in an image are likely to grab visual attention, based on contrast, color, edges — not based on real eye-tracking data, just statistics about the image itself. |
| **Spectral Residual (Hou & Zhang, 2007)** | A specific, real, peer-reviewed algorithm that estimates saliency by looking at which parts of an image are "surprising" in the frequency domain (i.e., different from the image's overall pattern). |
| **Fine-Grained saliency** | A second, complementary saliency algorithm built into OpenCV; combining two algorithms (an "ensemble") gives a more stable estimate than relying on one. |
| **Face detector / ONNX / UltraFace** | A small pretrained neural network that finds faces in an image. ONNX is just a standard file format for pretrained models that lets different software (like OpenCV) load and run them. UltraFace is the specific, lightweight model used here. |
| **NMS (Non-Maximum Suppression)** | A cleanup step after face detection: the raw model often proposes several overlapping boxes for the same face; NMS keeps the best one and discards the redundant ones. |
| **OCR (Optical Character Recognition)** | Software (Tesseract, in this case) that reads text out of an image and tells you where each word is located (pixel coordinates), used here to automatically find the headline, offer amount, and CTA text regions instead of guessing coordinates by hand. |
| **AOI (Area of Interest)** | A named, bounded region of the image (e.g. "CTA button", "Face", "Offer Amount") that attention is measured *within*, rather than just reporting a vague heatmap blob. This is how real commercial neuromarketing tools structure their output. |
| **Heatmap** | A color-coded visualization (blue = low, red = high) of the saliency score at every pixel, overlaid on the original image. |
| **Entropy / Focus score** | A mathematical measure (borrowed from information theory) of how *spread out* a distribution is. Applied here to the AOI attention shares: if one AOI has almost all the attention, entropy is low (score close to 1 = concentrated/good). If attention is split evenly across many AOIs, entropy is high (score close to 0 = fragmented/bad) — this is the direct computational version of your own observation that too many competing focal points dilute attention. |
| **Gaze path / scanpath** | A predicted sequence of where the eye lands, in order — not just *how much* attention a region gets, but *when* in the viewing sequence. Built here by ranking AOIs by attention share (highest first) — the same "winner-take-all" logic used in classic scanpath research (Itti, Koch & Niebur, 1998). |
| **Competition vs. Synergy** | Competition = two AOIs with similar attention share, spatially close together — an ambiguous fight for the same glance (bad). Synergy = a clear, ordered sequence where each AOI hands off to the next in a sensible narrative (brand → offer → trust signal → action) (good). |

## 5. The Focus Score formula, explained simply

For each AOI, you get a % share of total predicted attention. The Focus score treats these shares like a probability distribution and computes **normalized Shannon entropy**, then flips it so higher = more concentrated:

```
Focus = 1 − (entropy of AOI shares) / (maximum possible entropy for that many AOIs)
```

- If **one** AOI has 100% of the attention → entropy = 0 → Focus = 1.0 (perfectly concentrated)
- If attention is **split evenly** across all AOIs → entropy = maximum → Focus = 0.0 (perfectly fragmented)

This is a direct, real mathematical translation of the idea you described in your own words: *"brain has limited time and resource to focus, too many focus points means brain has to allocate more."* Entropy is the standard tool in information theory for measuring exactly that kind of "spread."

## 6. How this compares to real commercial neuromarketing science

Partway through this project you found and shared **Neurons AI's actual technical whitepaper** — a real commercial platform with genuine proprietary human data behind it (1 billion+ real eye-tracking data points, 25,000+ participants in implicit-response testing, validated against held-out human ground truth using three named statistical metrics: **Pearson CC, KLD, and SIM**).

**Important honesty point for your interview**: this pipeline does **not** clear that bar, and neither did any of the other AI tools tested (ChatGPT, Kimi, Grok) — none of us have access to real proprietary eye-tracking data, so none of us can produce a *validated* prediction. What this pipeline does that the other AI outputs didn't: **it's honest about that gap.** Every number here comes from a real, running, citable algorithm — not an invented percentage. That distinction (real-but-unvalidated heuristic vs. fabricated-but-confident-sounding number) is the single most important thing this project demonstrates, and it's a genuinely good story for an interview: you didn't just use AI tools, you **audited** them, caught them fabricating precision, and built something more honest.

## 7. Results summary (the numbers, for quick reference)

| Version | Focus score | Competition flags | Notes |
|---|---|---|---|
| Original flat-graphic HDFC banner | 0.531 | 2 (Face vs. Bank Logo; Offer vs. Cashback) | 69% of attention on background glow, not content |
| Same, after pixel-editing fixes | 0.475 | 1 new (Face vs. new CTA) | Fixed 2 issues, added CTA created a 3rd — net-neutral, explained below |
| AI-generated photoreal HDFC banner (baseline) | 0.338 | 6 | Four elements tied 9.8–13.4% — exactly the "too many focal points" problem |
| Same, after color/saturation tweaks | 0.347 | 6 | Barely moved — proved the problem was structural, not cosmetic |
| Same, after real layout change (relocate/shrink) | 0.476 | 2 | Real fix — proved layout > color for this class of problem |
| **Fresh generation from an AOI-informed prompt** | **0.505** | **1 (weak)** | **Best result** — offer amount went from ~13% (3-way tie) to 40.7% (clear winner) |

**Why the "after pixel-editing fixes" row isn't simply better than the original**: adding a CTA button was necessary (the original had zero clickable element), but any visible CTA is, by definition, salient — so it necessarily adds a new competing focal point, which mechanically lowers the entropy-based Focus score even though the design objectively improved. This is a real limitation of the Focus score used alone: **it can't distinguish two elements competing for the same glance from two elements each legitimately deserving separate attention in sequence.** You have to read the score together with the gaze-path order, not in isolation. This is a good nuance to mention if asked "what would you improve about your own metric" in an interview.

## 8. A genuinely interesting technical finding (good interview anecdote)

While testing whether a bold, flat-color CTA button was under-scoring, I ran a controlled test: built two identical mock buttons — one with a solid flat color fill, one with an added border — and measured both in isolation. **The bordered version scored ~45% higher**, purely because classical saliency algorithms respond to edge/frequency complexity, not to color contrast on its own. This is a real, demonstrable **blind spot** in this class of 1998-2007-era computer vision algorithm — real human vision is well known to respond strongly to flat color "pop-out" (a finding from Treisman's Feature Integration Theory), which these older algorithms don't fully capture. This is exactly the kind of gap that modern deep-learning saliency models (trained directly on human eye-tracking data, e.g. DeepGaze IIE/III) close — see Section 9 for why those weren't usable here.

## 9. Limitations (say these clearly if asked — it builds credibility, not weakness)

1. **Not validated against real human ground truth.** No Pearson CC / KLD / SIM comparison exists for this pipeline's output, unlike Neurons AI's platform. Every score is a heuristic, not a measurement.
2. **Uses 2007/2009-era classical algorithms**, not modern deep-learning saliency models. A real upgrade path (`deepgaze_pytorch`, DeepGaze IIE/III) was identified and attempted, but its pretrained weights are hosted on infrastructure (GitHub release CDN, torchvision's weight server) blocked by this environment's network policy — confirmed via actual failed download attempts, not assumed.
3. **Demonstrated bias toward textured/high-frequency regions** over flat color UI elements (Section 8) — a known limitation of this specific algorithm family.
4. **The Focus score alone can't distinguish "bad competition" from "good sequential synergy"** — needs to be read alongside the gaze-path order, not as a single number in isolation.
5. **AOI boxes are semi-manual** — text boxes come from real OCR, but logo/graphic boxes were hand-annotated by visual inspection, which introduces some subjectivity.

## 10. Suggested interview talking points

- **"Walk me through a project you're proud of."** → Use Section 3 (chain of thought) — it's a real debugging story with genuine dead ends and fixes, not a tutorial.
- **"Do you know Python?"** → Be direct: *"I don't write Python from scratch, but I've built and directed a full working pipeline using AI pair-programming, and I understand every component, every algorithm it uses, and — importantly — where it's genuinely valid versus where it's a heuristic. I know the difference between a real computed number and a plausible-sounding invented one, which is actually the core skill this project is about."*
- **"What would you do differently with more resources?"** → Real deep-learning saliency model (DeepGaze IIE/III) trained on actual human eye-tracking data, and ideally validating against a real panel test (even a small one) rather than relying purely on computed heuristics.
- **"Why does this matter for a neuromarketing/growth role?"** → Because most "AI neuromarketing" content in the market right now (as this project directly demonstrated across four different AI tools) is fabricated precision dressed up as science. Being able to tell the difference — and build the honest version — is a genuinely differentiated, hire-able skill.

## 12. Erratum — a real bug found and fixed after initial delivery

**What was wrong:** the original `focus_score` function used each AOI's raw share (e.g. 23.2% → 0.232) directly as a pseudo-probability in the entropy formula, without renormalizing so the values summed to 1. Since AOI shares never actually sum to 100% (some attention always lands on unassigned background), this made the score sensitive to **how much total attention got captured by named regions**, not just **how that captured attention was distributed among them**. Two creatives with identical concentration shape but different total-captured-mass could get different, non-comparable scores.

**How it was caught:** while comparing a baseline recharge banner (34.5% of attention captured by AOIs) against a redesign (45.4% captured, zero competition flags, headline dominance jumped from 4.6% to 23.2%), the buggy formula reported the *redesign* as less concentrated (0.467) than the *baseline* (0.518) — directly contradicting the competition-flag count and the per-AOI shares, which both clearly favored the redesign. That inconsistency is what triggered the investigation.

**The fix:** renormalize the AOI shares to sum to 1 before computing entropy, so the score purely measures distribution shape.

**Corrected numbers for that case:**
| | Buggy formula | Corrected formula |
|---|---|---|
| Baseline | 0.518 | **0.115** |
| Redesign | 0.467 | **0.233** |

Under the fix, the redesign is roughly double the concentration of the baseline — consistent with the rest of the evidence.

**What this means for earlier results in this document:** the distortion is largest when comparing two versions with very different total captured-attention mass. Most before/after comparisons in this project had more similar totals between versions, so conclusions likely hold — but this hasn't been individually re-verified for every case, and the honest position is "probably fine, not confirmed" until it is. If precision matters for a specific comparison, re-run it with the patched function rather than trusting the original numbers reported earlier in this document.

**Good interview material, honestly:** finding and fixing a real bug in your own measurement tool — one that could have flipped a real conclusion — is a stronger story than a pipeline that never needed debugging. It's also a direct demonstration of the exact skill this whole project has been about: not trusting a confident-looking number without checking what's actually behind it, including your own numbers.

## 14. Two additions — global-effect (weighted-attention) model and motion salience

**Trigger for both:** a request to explore whether "superposition of attention" — multiple candidate attention targets coexisting before one is selected — has any real, implementable basis, rather than being a decorative metaphor.

### 14a. The global effect / averaging-saccade model (`averaging_saccade_prediction` in `saliency_pipeline.py`)

**The real science:** the "global effect" or "averaging saccade" phenomenon is mainstream, uncontested oculomotor research (Findlay, 1982, and 40+ years of replication — PLOS Biology 2018, Journal of Vision 2013, and many more). When two salient targets sit close together, the eye does not cleanly choose one — it lands at the population-weighted centroid between them, sometimes on neither target.

**What it adds:** the pipeline's existing competition detector could already say "these two AOIs are competing." This adds a sharper, mechanistically distinct claim: an actual predicted (x, y) landing coordinate, and a hard classification of whether that predicted fixation lands on *either* competing element or on empty space between them — a literal "wasted fixation" prediction.

**Honest scope:** the global effect is best-documented for short-latency, *reflexive* saccades specifically — it weakens for slower, deliberate viewing. This is framed as modeling the very first, fastest glance (relevant to fast-scroll social/ad contexts), not the entire viewing sequence.

**What was explicitly rejected before landing on this:** the original prompt that led here was about "superposition of attention" and recent papers on the topic. Real research search turned up *quantum cognition* (Busemeyer & Bruza, 2012; Pothos & Busemeyer in *Proc. Royal Society B* and *Behavioral and Brain Sciences*) — a genuine peer-reviewed field using quantum *probability formalism* (not literal physics) to model context-dependent judgment. But a 2026 *Frontiers in Psychology* critical review was found stating plainly that much of the adjacent literature uses "superposition" as verbal decoration without testable mechanisms. That distinction mattered: the quantum-cognition framing was set aside in favor of the global-effect model above, which achieves the same "multiple candidates held in a weighted state before collapse" idea using mainstream, uncontested vision science instead.

### 14b. Motion salience — Hassenstein-Reichardt correlator (`motion_emd.py`, new file)

**The real science:** the Hassenstein-Reichardt correlator (1956) is a motion-detection model literally reverse-engineered from insect (beetle/fly) motion-perception experiments, still cited today as legitimate front-end architecture for optic-flow computation.

**Trigger:** a viral trend (Sept 2026) of running the newly-published MaleCNS v1.0 fruit-fly connectome (166,700 neurons, full CNS) through toy simulations for unrelated tasks (games, trading). That full-connectome approach was explicitly rejected as a literal input to this pipeline — a fly's CNS is overwhelmingly flight/olfaction/motor circuitry with no analog for text, faces, or brand logos; wiring it in would have been the same fabricated-legitimacy mistake this whole project exists to catch in other tools. The one piece that *does* transfer honestly is the correlator model itself, not the connectome.

**What it adds:** every prior part of this pipeline is static-image only. This extends it to video/animated creative (Reels, animated banners, GIFs) — a real, previously-unaddressed gap, since a moving CTA pulse or animated flourish can dominate attention in ways no single frame can capture.

**Validated:** on a synthetic two-frame test before any real use — a moving dot cleanly separated from a static noisy background (0.00 mean energy on background vs. 15.98 in the motion path), and direction discrimination confirmed to flip sign correctly between opposite motions.

**What was explicitly rejected:** a separate idea (inspired by the "God's Eye View" viral OSINT/geospatial-fusion tool) to build a live competitive-intelligence layer by scraping Meta Ad Library. Tested directly — blocked by robots.txt, same as every other social platform hit in this project. Documented here as a rejected idea, not a working feature: the manual workaround (person pulls competitor screenshots themselves, pipeline analyzes them) is what's actually usable today.

## 15. Files in this package

- `saliency_pipeline.py` — the core reusable module (AOI scoring, Focus score, competition detection, gaze path, and the global-effect/averaging-saccade model)
- `motion_emd.py` — the motion-salience module (Hassenstein-Reichardt correlator), for video/animated creative
- `run_analysis.py` — a runnable end-to-end example script
- `download_models.py` — fetches the one required model file (UltraFace ONNX)
- `requirements.txt` — Python/system dependencies
- This file (`NOTES.md`)
