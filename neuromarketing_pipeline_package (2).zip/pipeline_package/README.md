# Computational Ad-Attention Screening Pipeline

A lightweight, fully-local pipeline that predicts attention distribution on ad creative using published computational saliency algorithms + face detection + OCR-based AOI (Area-of-Interest) mapping — built to screen for competing focal points before creative goes to spend.

**Start here:** read `NOTES.md` first — it has the full project story, methodology, results, and honest limitations, written for both technical and non-technical readers.

## Quick start

```bash
pip install -r requirements.txt
# also needs the Tesseract OCR binary installed at the system level:
#   apt-get install tesseract-ocr   (Ubuntu/Debian)
#   brew install tesseract          (Mac)

python3 download_models.py          # fetches the face detector (~1.2MB)
python3 run_analysis.py your_ad.png # edit the AOI list inside the script for your creative's layout
```

## What it outputs

- A per-AOI attention share breakdown (% of predicted attention landing in each named region: logo, headline, offer, CTA, etc.)
- A **Focus score** (0–1): how concentrated vs. fragmented attention is across the creative
- **Competition flags**: pairs of AOIs fighting for the same glance (near-equal attention share, spatially close)
- A **gaze path**: the predicted fixation order, drawn as numbered arrows over a heatmap, so you can see whether the creative tells a coherent visual story or jumps around incoherently

## Project files

| File | Purpose |
|---|---|
| `NOTES.md` | **Read this first.** Full chain-of-thought, methodology, results, limitations, interview talking points |
| `saliency_pipeline.py` | Core module — all the actual algorithms |
| `run_analysis.py` | Runnable example — start here to run it yourself |
| `download_models.py` | Fetches the required face-detection model |
| `requirements.txt` | Dependencies |

## Honesty note

This is a **heuristic screening tool**, not a validated prediction. It is not benchmarked against real human eye-tracking ground truth. See `NOTES.md` Section 9 for the full limitations list — read that before presenting this as more than it is.
